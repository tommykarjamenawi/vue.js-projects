<?php
namespace Models;

class Category {

    public int $id;
    public string $name;
  
}

?>